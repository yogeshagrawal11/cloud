
def multi_function(request):
    output = {}
    output["output"] = int(request.args["firstno"]) * int(request.args["secondno"])
    print(output)
    return output