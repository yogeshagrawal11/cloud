
def sq_function(request):
    output = {}
    output["output"] = int(request.args["firstno"]) * int(request.args["firstno"])
    print(output)
    return output