import boto3
import json
from dateutil.parser import *
import subprocess
from datetime import timedelta, datetime, tzinfo, timezone
import time
import pytz



#### Function to convert comment into Dictionary object
def objcommentfunc(comment):
    objdir = {} 

    try:
        if ";" in comment:
            for i in comment.split(";"):
                objdir[i.split(":")[0]] = i.split(":")[1].split(",")
        else:
            objdir[comment.split(":")[0]] = comment.split(":")[1].split(",")

    except Exception as e:
        print(e)
        print ("exception as function objcommentfunc")
    return objdir

#### function to create list of instance id that needed to be shutdown or startup 
#### 
def system_fuction(paginator, weekofday , hour, mytask):
    if "shutdown" == mytask: 
        response_iterator = paginator.paginate(Filters=[{'Name':"tag-key", 'Values':["shutdown"]},{'Name':"instance-state-name", 'Values':["running"]}])
    else:
        response_iterator = paginator.paginate(Filters=[{'Name':"tag-key", 'Values':["shutdown"]},{'Name':"instance-state-name", 'Values':["stopped"]}])
    
    toterminate = []
    tostart = []

    ### response iterator for corresponding 
    for j in response_iterator:
        for i in  j["Reservations"]:
            try:
                comment = ""
                for instance in i["Instances"]:
                    #print (instance)
                    #print ("\n\n")

                    for i in instance["Tags"]:
                        if i["Key"] == "shutdown":
                            comment = i["Value"]
                            objcomment = objcommentfunc(comment)
                            
                            if hour in objcomment[weekofday]:
                                #print ("Shutdown instance.........................")
                                toterminate.append(instance["InstanceId"])
                            else:
                                tostart.append(instance["InstanceId"])
                    print("Instance: {} State: {}  Tag: {} ".format(instance["InstanceId"], instance["State"]["Name"], comment))
            except Exception as e:
                print(e)
                continue

    
    if "shutdown" == mytask: 
        return toterminate
    else:
        return tostart



def lambda_handler(event, context):


    ec2_client = boto3.client("ec2")

    ### this will region to timezone mapping. If new region needs to be added here where instance checks need to present
    regions = {"us-west-2" : "America/Los_Angeles", "us-west-1" : "America/Los_Angeles" , 
            "us-east-1" : "America/New_York","us-east-2" : "America/New_York",
            'eu-north-1': "Europe/Stockholm", 'ap-south-1' : "Asia/Kolkata", 
            'eu-west-3': "Europe/Paris",'eu-west-2': "Europe/London",
            'eu-west-1': "Europe/Dublin", 'ap-northeast-2': "Asia/Seoul", 
            'ap-southeast-1': "Asia/Singapore", 'ap-southeast-2': "Australia/Sydney", 
            'eu-central-1': "Europe/Berlin"
            }


    try:
        for region in regions.keys():
            datestr = datetime.now(tz=pytz.timezone(regions[region]))
            weekday = (datetime.now(tz=pytz.timezone(regions[region]))).weekday()
            hour = str(datestr).split(":")[0].split()[-1]
            if hour == "00":
                hours = "0"
            else:
                hour = hour.lstrip("0")
            
            ### adding event information for cross verification
            print ("Checking {} Region {} day of week {}  hour {} - Local time {} ".format(region,regions[region],weekday ,hour, datestr ))

            if weekday <5 :
                weekofday = "weekday"
            else:
                weekofday = "weekend"
            

            
            ec2 = boto3.client("ec2",region_name = region)
            paginator = ec2.get_paginator("describe_instances")

            ### function will provide list of instances that needed to start and stop
            toshutdown = system_fuction(paginator, weekofday , hour, "shutdown")
            tostartup = system_fuction(paginator, weekofday , hour, "startup")

            
            if len(toshutdown) > 0 :
                response = ec2.stop_instances(InstanceIds=toshutdown)
                print(response)
            if len(tostartup) > 0 :
                response = ec2.start_instances(InstanceIds=tostartup)
                print(response)
        

    except Exception as e:
        print(e)


